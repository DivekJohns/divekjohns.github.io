self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b5d1ab841e4f1b369f06e13566d66139",
    "url": "/index.html"
  },
  {
    "revision": "d5a722e15533d8b96eff",
    "url": "/static/css/3.24a2ac1d.chunk.css"
  },
  {
    "revision": "3a140553085ee209cc2d",
    "url": "/static/css/4.c9653132.chunk.css"
  },
  {
    "revision": "aadb826bf856cc634d92",
    "url": "/static/css/main.fb60f13b.chunk.css"
  },
  {
    "revision": "a90225e1e92e28204337",
    "url": "/static/js/2.301c9487.chunk.js"
  },
  {
    "revision": "6e1d2efc12a1ac972ff1f942df7eb0bd",
    "url": "/static/js/2.301c9487.chunk.js.LICENSE.txt"
  },
  {
    "revision": "d5a722e15533d8b96eff",
    "url": "/static/js/3.72594e91.chunk.js"
  },
  {
    "revision": "3a140553085ee209cc2d",
    "url": "/static/js/4.c87989d6.chunk.js"
  },
  {
    "revision": "aadb826bf856cc634d92",
    "url": "/static/js/main.2ac48b3d.chunk.js"
  },
  {
    "revision": "f3d02fe788e90be79f35",
    "url": "/static/js/runtime-main.b5d83dbe.js"
  },
  {
    "revision": "21f233e19402cc4a66866a7f31191f0d",
    "url": "/static/media/Agustina.21f233e1.woff"
  },
  {
    "revision": "ee6539921d713482b8ccd4d0d23961bb",
    "url": "/static/media/Montserrat-Regular.ee653992.ttf"
  },
  {
    "revision": "0bb1712abdcb7a65bb398f62245df0c9",
    "url": "/static/media/chargerAnyalsis.0bb1712a.png"
  },
  {
    "revision": "5b0b631c21ba750c93648d9045782386",
    "url": "/static/media/chromafan.5b0b631c.png"
  },
  {
    "revision": "47a7a717679b640ceb1b05d38c480a61",
    "url": "/static/media/codeInLogo.47a7a717.webp"
  },
  {
    "revision": "51cf7192327488da3d2a171280680c16",
    "url": "/static/media/contactMailDark.51cf7192.svg"
  },
  {
    "revision": "d9d29fa5f604ac159171d8eb14683823",
    "url": "/static/media/dental.d9d29fa5.png"
  },
  {
    "revision": "59389695208d7454c6607bed51ed4316",
    "url": "/static/media/developerActivity.59389695.svg"
  },
  {
    "revision": "3f88945928009a8d22f7bd409e19fd56",
    "url": "/static/media/facebookLogo.3f889459.png"
  },
  {
    "revision": "3b9add9b449eb2883cd68246ef3aa27a",
    "url": "/static/media/fortify.3b9add9b.png"
  },
  {
    "revision": "e79c639294c805688be731921368c8f8",
    "url": "/static/media/googleAssistantLogo.e79c6392.webp"
  },
  {
    "revision": "0043502d4c8cd1db9e4e1fb3c273c862",
    "url": "/static/media/harvardLogo.0043502d.png"
  },
  {
    "revision": "52be31441c8cf8a8a16bd7a228d428bf",
    "url": "/static/media/manOnTable.52be3144.svg"
  },
  {
    "revision": "11f705bdd7d61f6cf3c8b38a7db978d7",
    "url": "/static/media/nextuLogo.11f705bd.webp"
  },
  {
    "revision": "ee62cb58630f29a6e6201b49d4c03728",
    "url": "/static/media/pwaLogo.ee62cb58.webp"
  },
  {
    "revision": "0736511f500e896b64845e54323d1e96",
    "url": "/static/media/quoraLogo.0736511f.png"
  },
  {
    "revision": "a2830df85caf1cce2ba7a0205c407dc3",
    "url": "/static/media/saayaHealthLogo.a2830df8.png"
  },
  {
    "revision": "0d03f7e35eedd543d99ca47f3c1e62fd",
    "url": "/static/media/satix.0d03f7e3.png"
  },
  {
    "revision": "3440939881da8339d1597e8d77cdf850",
    "url": "/static/media/skill.34409398.svg"
  },
  {
    "revision": "5d8a8c97368ede09794591a5f945a1cd",
    "url": "/static/media/stanfordLogo.5d8a8c97.png"
  },
  {
    "revision": "13780cdd0144cacdef25486e2c2503f8",
    "url": "/static/media/talksCardBack.13780cdd.svg"
  },
  {
    "revision": "46f318ee19630c6d40d1297490b5d7e3",
    "url": "/static/media/tipster.46f318ee.png"
  },
  {
    "revision": "746243f33f362aaeadaea85537e6b913",
    "url": "/static/media/wsa.746243f3.png"
  }
]);